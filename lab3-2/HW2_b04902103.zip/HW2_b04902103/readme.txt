studentID:
b04902103

Version:
python3

How to build:

How to run:
python3 AES_CPA.py Trace.csv Ciphertext.csv