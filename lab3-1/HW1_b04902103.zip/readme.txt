studentID:
b04902103

Key:
35a87c24cb868edfbb41a7432dcd53dc

Version:
python3

How to build:

How to run:
python3 main.py [-h] [-b B] [-noise NOISE] [-key KEY] input_csv